export const CommentAddedSubscriptionName = 'commentAdded';
